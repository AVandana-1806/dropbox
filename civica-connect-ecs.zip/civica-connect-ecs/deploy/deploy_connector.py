"""
Civica Connect Deployment Script.

Rolls out a new image version to the ECS service and applies the connector config, without touching the
infrastructure. The CloudFormation stack (infra plus ECS) is created and changed only through the
CloudFormation process; this script updates just its ImageUri parameter, reusing the deployed template and
every other parameter as-is. If the stack already runs that image, the rollout is skipped and only the
connector config is applied with PUT /connectors/{name}/config (create or update, offsets kept).

Usage (all settings come from the environment, e.g. set by the buildspec):
  STACK_NAME=civica-connect-cares300 IMAGE_URI=<ecr repo>:1.0.5 CONNECTOR_NAME=cares-civica-connector-cares300 \\
  CONNECTOR_PROPERTIES=deploy/connector-cares300.properties python3 deploy_connector.py
"""

import json
import logging
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass

import boto3
from botocore.exceptions import ClientError, WaiterError


def _configure_logging():
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s %(levelname)s [%(name)s] %(message)s"
    )
    for name in ("boto3", "botocore"):
        logging.getLogger(name).setLevel(logging.WARNING)


_configure_logging()
LOGGER = logging.getLogger("civica_connect_deploy")
SESSION = boto3.Session()

# Connector keys that must be supplied through a config provider (${env:...}), never as plaintext,
# because the REST payload is stored in the Connect configs topic.
SECRET_KEYS = frozenset(
    {
        "sfdc.consumerkey",
        "sfdc.consumersecret",
        "sfdc.user",
        "sfdc.password",
        "civica.basic.auth.user",
        "civica.basic.auth.pwd",
    }
)
HTTP_TIMEOUT_SECONDS = 30
# Connect answers 409 while the worker group is rebalancing; the same call succeeds once it settles.
REBALANCE_STATUS = 409
IMAGE_PARAMETER = "ImageUri"
REST_URL_OUTPUT = "ConnectRestUrl"


class DeployError(Exception):
    """Signal that the deployment could not complete."""


def read_properties(path: str) -> dict:
    """Read a flat key=value properties file, skipping blanks and '#' comments."""
    props = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                key, _, value = line.partition("=")
                props[key.strip()] = value.strip()
    return props


@dataclass(frozen=True)
class DeployConfig:
    """Resolved settings for one deployment."""

    stack_name: str
    image_uri: str
    connector_name: str
    properties_path: str
    ready_timeout_seconds: int
    running_timeout_seconds: int
    poll_seconds: int

    @classmethod
    def from_env(cls) -> "DeployConfig":
        """Build the config from environment variables."""
        return cls(
            stack_name=os.environ["STACK_NAME"],
            image_uri=os.environ["IMAGE_URI"],
            connector_name=os.environ["CONNECTOR_NAME"],
            properties_path=os.environ["CONNECTOR_PROPERTIES"],
            ready_timeout_seconds=int(os.environ.get("READY_TIMEOUT_SECONDS", "300")),
            running_timeout_seconds=int(os.environ.get("RUNNING_TIMEOUT_SECONDS", "300")),
            poll_seconds=int(os.environ.get("POLL_SECONDS", "10")),
        )


class StackDeployer:
    """Roll out a new image through the existing CloudFormation stack."""

    def __init__(self, stack_name: str, client=None):
        self.stack_name = stack_name
        self.client = client or SESSION.client("cloudformation")

    def describe(self) -> dict:
        """Return the stack, failing if the CloudFormation process has not created it yet."""
        try:
            return self.client.describe_stacks(StackName=self.stack_name)["Stacks"][0]
        except ClientError as e:
            raise DeployError(
                f"stack '{self.stack_name}' not found; create it through the CloudFormation process first ({e})"
            ) from e

    def rest_url(self) -> str:
        """Return the Connect REST URL from the stack outputs."""
        outputs = {o["OutputKey"]: o["OutputValue"] for o in self.describe().get("Outputs", [])}
        if REST_URL_OUTPUT not in outputs:
            raise DeployError(f"stack '{self.stack_name}' has no {REST_URL_OUTPUT} output")
        return outputs[REST_URL_OUTPUT].rstrip("/")

    def rollout(self, image_uri: str):
        """Update only the ImageUri parameter and wait for ECS to finish rolling out."""
        stack = self.describe()
        current = {p["ParameterKey"]: p.get("ParameterValue") for p in stack["Parameters"]}
        if IMAGE_PARAMETER not in current:
            raise DeployError(f"stack '{self.stack_name}' has no {IMAGE_PARAMETER} parameter")
        if current[IMAGE_PARAMETER] == image_uri:
            LOGGER.info("Stack already runs %s; skipping rollout.", image_uri)
            return

        LOGGER.info("Rolling out %s (was %s) on stack '%s'.", image_uri, current[IMAGE_PARAMETER], self.stack_name)
        parameters = [
            {"ParameterKey": key, "ParameterValue": image_uri}
            if key == IMAGE_PARAMETER
            else {"ParameterKey": key, "UsePreviousValue": True}
            for key in current
        ]
        try:
            self.client.update_stack(
                StackName=self.stack_name,
                UsePreviousTemplate=True,
                Parameters=parameters,
                Capabilities=["CAPABILITY_IAM"],
            )
            self.client.get_waiter("stack_update_complete").wait(
                StackName=self.stack_name, WaiterConfig={"Delay": 15, "MaxAttempts": 120}
            )
        except WaiterError as e:
            status = self.describe().get("StackStatus")
            raise DeployError(f"stack update did not complete (status {status}); see the stack events") from e
        LOGGER.info("Rollout of %s complete.", image_uri)


class ConnectClient:
    """Call the Kafka Connect REST API."""

    def __init__(self, base_url: str):
        self.base_url = base_url

    def request(self, method: str, path: str, body: dict | None = None) -> tuple[int, dict | list | None]:
        """Send one request and return (status, parsed JSON body)."""
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(
            self.base_url + path,
            data=data,
            method=method,
            headers={"Content-Type": "application/json", "Accept": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT_SECONDS) as resp:
                return resp.status, self._parse(resp.read())
        except urllib.error.HTTPError as e:
            return e.code, self._parse(e.read())

    @staticmethod
    def _parse(raw: bytes):
        if not raw:
            return None
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return {"message": raw.decode(errors="replace")}


class ConnectorDeployer:
    """Apply the connector config and wait for it to run."""

    def __init__(self, config: DeployConfig, client: ConnectClient):
        self.config = config
        self.client = client
        self.path = "/connectors/" + urllib.parse.quote(config.connector_name, safe="")

    def load_connector_config(self) -> dict:
        """Read the connector properties and reject plaintext secrets."""
        props = read_properties(self.config.properties_path)
        plaintext = sorted(k for k in SECRET_KEYS & props.keys() if not props[k].startswith("${"))
        if plaintext:
            raise DeployError(
                f"{plaintext} must reference a config provider (e.g. ${{env:CONNECTOR_SECRET_...}}), "
                "not plaintext values"
            )
        props["name"] = self.config.connector_name
        return props

    def wait_until_ready(self):
        """Wait until the REST API answers."""
        deadline = time.monotonic() + self.config.ready_timeout_seconds
        while True:
            try:
                status, body = self.client.request("GET", "/")
                if status == 200:
                    LOGGER.info("Connect REST API is up (version %s)", (body or {}).get("version"))
                    return
                LOGGER.info("Connect REST API answered %s; waiting", status)
            except (urllib.error.URLError, TimeoutError, ConnectionError) as e:
                LOGGER.info("Connect REST API not reachable yet: %s", e)
            if time.monotonic() > deadline:
                raise DeployError("timed out waiting for the Connect REST API")
            time.sleep(self.config.poll_seconds)

    def put_config(self, connector_config: dict):
        """Create or update the connector, retrying while the group rebalances."""
        deadline = time.monotonic() + self.config.ready_timeout_seconds
        while True:
            status, body = self.client.request("PUT", self.path + "/config", connector_config)
            if status in (200, 201):
                LOGGER.info("Connector '%s' %s.", self.config.connector_name,
                            "created" if status == 201 else "updated")
                return
            if status != REBALANCE_STATUS or time.monotonic() > deadline:
                raise DeployError(f"PUT config failed with {status}: {body}")
            LOGGER.info("Worker group is rebalancing (409); retrying")
            time.sleep(self.config.poll_seconds)

    def wait_until_running(self):
        """Wait until the connector and every task are RUNNING; fail fast on FAILED."""
        deadline = time.monotonic() + self.config.running_timeout_seconds
        while True:
            status, body = self.client.request("GET", self.path + "/status")
            if status == 200 and body:
                connector_state = body["connector"]["state"]
                tasks = body.get("tasks", [])
                failed = [t for t in tasks if t["state"] == "FAILED"]
                if connector_state == "FAILED" or failed:
                    trace = body["connector"].get("trace") or (failed[0].get("trace") if failed else "")
                    raise DeployError(f"connector or task FAILED:\n{trace}")
                if connector_state == "RUNNING" and tasks and all(t["state"] == "RUNNING" for t in tasks):
                    LOGGER.info("Connector RUNNING with %d task(s) on %s", len(tasks),
                                sorted({t["worker_id"] for t in tasks}))
                    return
                LOGGER.info("Connector %s, tasks %s; waiting", connector_state, [t["state"] for t in tasks])
            if time.monotonic() > deadline:
                raise DeployError("timed out waiting for the connector to reach RUNNING")
            time.sleep(self.config.poll_seconds)

    def deploy(self):
        """Apply the connector config."""
        connector_config = self.load_connector_config()
        self.wait_until_ready()
        self.put_config(connector_config)
        self.wait_until_running()


def main():
    """Main entry point."""
    try:
        config = DeployConfig.from_env()
        stack = StackDeployer(config.stack_name)
        stack.rollout(config.image_uri)
        ConnectorDeployer(config, ConnectClient(stack.rest_url())).deploy()
    except KeyError as e:
        LOGGER.error("Missing required environment variable: %s", e)
        sys.exit(1)
    except (OSError, ValueError, ClientError, DeployError) as e:
        LOGGER.error("Deployment failed: %s", e)
        sys.exit(1)
    LOGGER.info("Deployment complete")


if __name__ == "__main__":
    main()
