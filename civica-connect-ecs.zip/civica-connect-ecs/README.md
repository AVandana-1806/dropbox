# Civica Connect on ECS

Self-managed Kafka Connect cluster on ECS Fargate for the Civica sink connector, connecting to MSK over
mutual TLS (MSK Connect only supports IAM or no client authentication).

## Layout

- `docker/Dockerfile`: a Maven stage builds the shaded connector JAR (`--build-arg VERSION`), then the runtime
  stage is Amazon Corretto 21 on AL2023 (same base as the Snowflake Connect image) with Apache Kafka 4.2.0
  (matches `connect-api` in `pom.xml`) and the JAR in `/app/plugins/cares-civica-connector`.
- `docker/connect-distributed.properties`: static worker settings baked into the image, including the mTLS
  settings, which read the PEM key and certificate from env vars through the env config provider.
- `docker/connect-log4j2.yaml`: console-only logging (CloudWatch), so no log files build up in the task.
- `docker/start-kafka-connect.sh`: same pattern as the Snowflake worker script. Derives the IP, environment
  (container name suffix), group.id (task family), region and MSK bootstrap servers (looked up by the
  `cdi-db-infra--msk-cluster--<env>` name, TLS string) and the secrets at startup, sets the per-task values
  in place with `set_prop` and execs the worker.
- `cloudformation/civica-connect-ecs.yaml`: cluster, task definition (read-only root, `/app` volume), service,
  internal ALB, security groups, IAM, log group and CPU autoscaling.
- `deploy/deploy_connector.py`: rolls out a new image by updating only the stack's `ImageUri` parameter (reusing
  the deployed template), then creates or updates the connector with `PUT /connectors/{name}/config` and waits
  for RUNNING.
- `deploy/connector-<env>.properties`: connector config per environment.
- `buildspec.yml`: image build and push (skipped if `VERSION` is already in ECR), then
  `deploy_connector.py`. It never deploys the template.

## Copy into the connector repo

Put `docker/`, `cloudformation/`, `deploy/` and `buildspec.yml` at the root of the connector repo (next to
`pom.xml`). The Docker build context is the repo root, because the build stage copies `pom.xml` and `src/`.
Build locally with `docker build -f docker/Dockerfile --build-arg VERSION=1.0.0 -t civica-connect:1.0.0 .`
Also copy `.dockerignore` to the repo root, so `target/` and `.git` stay out of the build context.

## Secrets

The worker reads two secrets from Secrets Manager at startup. `start-kafka-connect.sh` builds their names from the
environment taken from the container name: `civica-connect/<env>/msk-client-cert` and
`civica-connect/<env>/connector` (e.g. `civica-connect/cares300/connector`). The template only takes their ARNs,
to grant the task role `secretsmanager:GetSecretValue`.

**MSK client certificate**: JSON keys from a certificate issued by the ACM Private CA that the MSK cluster
trusts (`aws acm export-certificate` returns all of them, with an encrypted key):

```json
{
  "certificate": "-----BEGIN CERTIFICATE-----\n...",
  "certificate_chain": "-----BEGIN CERTIFICATE-----\n...",
  "private_key": "-----BEGIN ENCRYPTED PRIVATE KEY-----\n...",
  "private_key_password": "..."
}
```

The private key must be PKCS#8 (`BEGIN PRIVATE KEY` or `BEGIN ENCRYPTED PRIVATE KEY`), which is what ACM
exports. The script exports these as `MSK_CLIENT_*` env vars and the worker reads them as inline PEM
(`ssl.keystore.key`, `ssl.keystore.certificate.chain`), so no keystore file is written. No truststore
is needed: MSK broker certificates are issued by Amazon Trust Services, which the JVM already trusts.

**Connector credentials**: JSON keys `sfdc_consumerkey`, `sfdc_consumersecret`, `sfdc_user`, `sfdc_password`,
`civica_user`, `civica_password`. The script exports them as `CONNECTOR_SECRET_*` env vars, and the connector
config references them as `${env:CONNECTOR_SECRET_...}`. They never pass through the REST API or get stored
in the Connect configs topic.

## Writable space

The root filesystem is read-only. The task mounts its own volume at `/app`, and `VOLUME ["/app"]` in the
Dockerfile makes ECS copy the image's `/app` into it at task start, the same as the Snowflake worker. The start
script edits `/app/kafka/config/connect-distributed.properties` in place. A second empty task volume is mounted
at `/opt` and used as `java.io.tmpdir` (Kafka's native compression libraries unpack there). Both volumes
belong to one task and are wiped when it stops; nothing needs to persist, so there's no EFS.

## Kafka ACLs (if the cluster enforces them)

The principal is the client certificate's subject, e.g. `User:CN=civica-connect-dev`. It needs:

- Topics with prefix `civica-connect-<env>-` (the internal topics): Create, Describe, DescribeConfigs, Read, Write.
- Group `civica-connect-<env>` (the worker group): Read.
- Topic `aws.data-integration.cdc.cares.salesforce.mdm.0`: Describe, Read.
- Group `connect-<connector name>` (the sink consumer group): Read.

## Migrating from MSK Connect

A sink connector's consumer group is `connect-<connector name>`. Use the same connector name as the MSK
Connect connector, so the ECS connector resumes from its committed offsets.

1. Deploy the stack and confirm the workers are healthy (`GET /` on the ALB).
2. Delete the MSK Connect connector and wait until it is gone, so the two never consume at the same time.
3. Run `deploy_connector.py` with the same `CONNECTOR_NAME`.

## Scaling

Each partition is consumed by one task, and `tasks.max` is 2 for a 2-partition topic, so at most 2 workers do
work. The service runs a minimum of 2 tasks for availability. Autoscaling above 2 only adds idle workers until
the topic has more partitions (and the publisher keys messages by person). Every scale event rebalances the
worker group, so scale-in is deliberately slow (15-minute cooldown). Tasks from a stopped worker are reassigned
after 1 minute (`scheduled.rebalance.max.delay.ms`).

## Operations

- REST API: `http://<ConnectRestUrl>/connectors/<name>/status`.
- Log levels can be changed at runtime, e.g.
  `curl -X PUT -H 'Content-Type: application/json' -d '{"level":"DEBUG"}' http://<ConnectRestUrl>/admin/loggers/gov.ca.cares`.
  Each worker applies this only to itself, so repeat it per worker or use `?scope=cluster`.
- Shell into a worker: `aws ecs execute-command --cluster civica-connect-<env> --task <id> --container civica-connect-<env> --interactive --command /bin/bash`.

## Infrastructure, releases and config changes

**Infrastructure** (cluster, ALB, security groups, IAM, task definition, service, task counts, CPU, memory) is
deployed and changed only through your CloudFormation process with `cloudformation/civica-connect-ecs.yaml`.
When you change infra, leave `ImageUri` on its previous value so the running version stays as it is.

**First deployment of an environment:** push the first image version, then create the stack through the
CloudFormation process with `ImageUri` set to it. The buildspec needs the stack to exist.

**Releases and config changes** go through `buildspec.yml`, decided by `VERSION`:

- **New version (code change):** the image is built and pushed, then `deploy_connector.py` updates the stack with
  the template that is already deployed, changing only `ImageUri` (every other parameter keeps its value). ECS
  rolls out the new tasks, then the connector config is applied. A release can never change infra, even if the
  template file in the repo was edited.
- **Same version (connector config change):** the build is skipped, the stack already runs that image so the
  rollout is skipped, and only the connector config is applied in place.
- Keep tag immutability on in ECR, so a version tag can never be overwritten.
- **Worker config change** (`docker/connect-distributed.properties`) is baked into the image, so it is a release
  with a new version.
- **Secret rotation:** the worker reads secrets at startup, so restart the tasks:
  `aws ecs update-service --cluster civica-connect-<env> --service civica-connect-<env> --force-new-deployment`.
