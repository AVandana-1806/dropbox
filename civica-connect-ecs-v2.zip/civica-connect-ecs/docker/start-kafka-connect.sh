#!/bin/bash
# Start a Kafka Connect worker in distributed mode on ECS Fargate, connecting to MSK over mTLS.
# Derives advertised host, env, region, group.id, storage topics and MSK bootstrap servers from ECS task
# metadata and the AWS CLI, writes the client keystore from the Secrets Manager values ECS injects
# (MSK_CLIENT_CERT, MSK_CLIENT_CERT_CHAIN, MSK_CLIENT_KEY, MSK_CLIENT_KEY_PASSWORD), then execs the worker.

set -eu

BASE_PROPS=/app/kafka/config/connect-distributed.properties
PROPS=/tmp/connect-distributed.properties
CERT_DIR=/tmp/certs
KEYSTORE=${CERT_DIR}/client-keystore.pem

require() {
  if [ -z "$2" ] || [ "$2" = "null" ]; then
    echo "ERROR: could not resolve $1" >&2
    exit 1
  fi
}

echo "Starting Kafka Connect worker in distributed mode"

# Container endpoint = this container (IP, name); /task endpoint = task definition (family, ARN)
CONTAINER_META=$(curl -sf "${ECS_CONTAINER_METADATA_URI_V4}")
TASK_META=$(curl -sf "${ECS_CONTAINER_METADATA_URI_V4}/task")

KAFKA_CONTAINER_HOSTNAME=$(echo "$CONTAINER_META" | jq -r '.Networks[0].IPv4Addresses[0]')
KAFKA_CONTAINER_ENVIRONMENT=$(echo "$CONTAINER_META" | jq -r '.Name' | sed 's/.*-//')
# e.g. "civica-connect-cares300" -> used as-is for group.id and topic prefix
SERVICE_NAME=$(echo "$TASK_META" | jq -r '.Family')
# Fargate sets AWS_REGION; fall back to the region field of the task ARN
REGION=${AWS_REGION:-$(echo "$TASK_META" | jq -r '.TaskARN' | cut -d: -f4)}

require KAFKA_CONTAINER_HOSTNAME "$KAFKA_CONTAINER_HOSTNAME"
require KAFKA_CONTAINER_ENVIRONMENT "$KAFKA_CONTAINER_ENVIRONMENT"
require SERVICE_NAME "$SERVICE_NAME"
require REGION "$REGION"
require MSK_CLIENT_CERT "${MSK_CLIENT_CERT:-}"
require MSK_CLIENT_KEY "${MSK_CLIENT_KEY:-}"
require MSK_CLIENT_KEY_PASSWORD "${MSK_CLIENT_KEY_PASSWORD:-}"

KAFKA_MSK_CLUSTER_ARN=$(aws kafka list-clusters --region "$REGION" \
  | jq -r --arg name "cdi-db-infra--msk-cluster--${KAFKA_CONTAINER_ENVIRONMENT}" \
      '.ClusterInfoList[] | select(.ClusterName == $name) | .ClusterArn')
require KAFKA_MSK_CLUSTER_ARN "$KAFKA_MSK_CLUSTER_ARN"

# mTLS listener (port 9094)
KAFKA_MSK_BOOTSTRAP_SERVERS=$(aws kafka get-bootstrap-brokers --region "$REGION" \
  --cluster-arn "$KAFKA_MSK_CLUSTER_ARN" | jq -r '.BootstrapBrokerStringTls')
require KAFKA_MSK_BOOTSTRAP_SERVERS "$KAFKA_MSK_BOOTSTRAP_SERVERS"

# Kafka's PEM keystore: private key followed by the certificate chain, leaf first.
umask 077
mkdir -p "$CERT_DIR"
{
  printf '%s\n' "$MSK_CLIENT_KEY"
  printf '%s\n' "$MSK_CLIENT_CERT"
  if [ -n "${MSK_CLIENT_CERT_CHAIN:-}" ]; then
    printf '%s\n' "$MSK_CLIENT_CERT_CHAIN"
  fi
} > "$KEYSTORE"

# Runtime copy of the baked-in file: strip the per-task keys, then append the resolved values.
grep -Ev '^(bootstrap\.servers|rest\.advertised\.host\.name|group\.id|(config|offset|status)\.storage\.topic|((consumer|producer|admin)\.)?ssl\.key\.password)=' \
  "$BASE_PROPS" > "$PROPS"

cat >> "$PROPS" <<EOF
bootstrap.servers=${KAFKA_MSK_BOOTSTRAP_SERVERS}
rest.advertised.host.name=${KAFKA_CONTAINER_HOSTNAME}
group.id=${SERVICE_NAME}
config.storage.topic=${SERVICE_NAME}-configs
offset.storage.topic=${SERVICE_NAME}-offsets
status.storage.topic=${SERVICE_NAME}-status
ssl.key.password=${MSK_CLIENT_KEY_PASSWORD}
consumer.ssl.key.password=${MSK_CLIENT_KEY_PASSWORD}
producer.ssl.key.password=${MSK_CLIENT_KEY_PASSWORD}
admin.ssl.key.password=${MSK_CLIENT_KEY_PASSWORD}
EOF

# The worker only needs the keystore file; keep the raw key material out of the JVM's environment.
unset MSK_CLIENT_CERT MSK_CLIENT_CERT_CHAIN MSK_CLIENT_KEY MSK_CLIENT_KEY_PASSWORD

echo "=== Kafka Connect Config ==="
echo "  region:                    ${REGION}"
echo "  environment:               ${KAFKA_CONTAINER_ENVIRONMENT}"
echo "  bootstrap.servers:         ${KAFKA_MSK_BOOTSTRAP_SERVERS}"
echo "  rest.advertised.host.name: ${KAFKA_CONTAINER_HOSTNAME}"
echo "  group.id:                  ${SERVICE_NAME}"
echo "  config.storage.topic:      ${SERVICE_NAME}-configs"
echo "  offset.storage.topic:      ${SERVICE_NAME}-offsets"
echo "  status.storage.topic:      ${SERVICE_NAME}-status"
echo "  keystore:                  ${KEYSTORE}"
echo "============================"

# Root filesystem is read-only; Kafka's scripts create LOG_DIR, so keep it on the /tmp volume.
export LOG_DIR=/tmp/kafka-logs
exec /app/kafka/bin/connect-distributed.sh "$PROPS"
