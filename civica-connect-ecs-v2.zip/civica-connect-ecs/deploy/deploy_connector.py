"""
Kafka Connect Connector Deployment Script.

Creates or updates one connector on the self-managed Connect cluster through its REST API, then
waits until the connector and all its tasks are RUNNING. Uses PUT /connectors/{name}/config, which
creates or updates in one idempotent call, so redeploys never need a DELETE and re-create.

Usage (all settings come from the environment, e.g. set by the buildspec):
  CONNECT_REST_URL=http://internal-alb... CONNECTOR_NAME=cares-civica-connector-dev \\
  CONNECTOR_PROPERTIES=deploy/connector.properties python3 deploy_connector.py
"""

import json
import logging
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass


def _configure_logging():
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s %(levelname)s [%(name)s] %(message)s"
    )


_configure_logging()
LOGGER = logging.getLogger("connector_deploy")

# Connector keys that must be supplied through a config provider (${env:...}), never as plaintext,
# because the REST payload is stored in the Connect configs topic.
SECRET_KEYS = frozenset(
    {
        "sfdc.consumerkey",
        "sfdc.consumersecret",
        "sfdc.user",
        "sfdc.password",
        "civica.basic.auth.user",
        "civica.basic.auth.pwd",
    }
)
HTTP_TIMEOUT_SECONDS = 30
# Connect answers 409 while the worker group is rebalancing; the same call succeeds once it settles.
REBALANCE_STATUS = 409


class DeployError(Exception):
    """Signal that the connector could not be deployed."""


def read_properties(path: str) -> dict:
    """Read a flat key=value properties file, skipping blanks and '#' comments."""
    props = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                key, _, value = line.partition("=")
                props[key.strip()] = value.strip()
    return props


@dataclass(frozen=True)
class DeployConfig:
    """Resolved settings for one connector deployment."""

    rest_url: str
    connector_name: str
    properties_path: str
    ready_timeout_seconds: int
    running_timeout_seconds: int
    poll_seconds: int

    @classmethod
    def from_env(cls) -> "DeployConfig":
        """Build the config from environment variables."""
        return cls(
            rest_url=os.environ["CONNECT_REST_URL"].rstrip("/"),
            connector_name=os.environ["CONNECTOR_NAME"],
            properties_path=os.environ["CONNECTOR_PROPERTIES"],
            ready_timeout_seconds=int(os.environ.get("READY_TIMEOUT_SECONDS", "300")),
            running_timeout_seconds=int(os.environ.get("RUNNING_TIMEOUT_SECONDS", "300")),
            poll_seconds=int(os.environ.get("POLL_SECONDS", "10")),
        )


class ConnectClient:
    """Call the Kafka Connect REST API."""

    def __init__(self, base_url: str):
        self.base_url = base_url

    def request(self, method: str, path: str, body: dict | None = None) -> tuple[int, dict | list | None]:
        """Send one request and return (status, parsed JSON body)."""
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(
            self.base_url + path,
            data=data,
            method=method,
            headers={"Content-Type": "application/json", "Accept": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT_SECONDS) as resp:
                return resp.status, self._parse(resp.read())
        except urllib.error.HTTPError as e:
            return e.code, self._parse(e.read())

    @staticmethod
    def _parse(raw: bytes):
        if not raw:
            return None
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return {"message": raw.decode(errors="replace")}


class ConnectorDeployer:
    """Deploy one connector and wait for it to run."""

    def __init__(self, config: DeployConfig, client: ConnectClient | None = None):
        self.config = config
        self.client = client or ConnectClient(config.rest_url)
        self.path = "/connectors/" + urllib.parse.quote(config.connector_name, safe="")

    def load_connector_config(self) -> dict:
        """Read the connector properties and reject plaintext secrets."""
        props = read_properties(self.config.properties_path)
        plaintext = sorted(k for k in SECRET_KEYS & props.keys() if not props[k].startswith("${"))
        if plaintext:
            raise DeployError(
                f"{plaintext} must reference a config provider (e.g. ${{env:CONNECTOR_SECRET_...}}), "
                "not plaintext values"
            )
        props["name"] = self.config.connector_name
        return props

    def wait_until_ready(self):
        """Wait until the REST API answers."""
        deadline = time.monotonic() + self.config.ready_timeout_seconds
        while True:
            try:
                status, body = self.client.request("GET", "/")
                if status == 200:
                    LOGGER.info("Connect REST API is up (version %s)", (body or {}).get("version"))
                    return
                LOGGER.info("Connect REST API answered %s; waiting", status)
            except (urllib.error.URLError, TimeoutError, ConnectionError) as e:
                LOGGER.info("Connect REST API not reachable yet: %s", e)
            if time.monotonic() > deadline:
                raise DeployError("timed out waiting for the Connect REST API")
            time.sleep(self.config.poll_seconds)

    def put_config(self, connector_config: dict):
        """Create or update the connector, retrying while the group rebalances."""
        deadline = time.monotonic() + self.config.ready_timeout_seconds
        while True:
            status, body = self.client.request("PUT", self.path + "/config", connector_config)
            if status in (200, 201):
                LOGGER.info("Connector '%s' %s.", self.config.connector_name,
                         "created" if status == 201 else "updated")
                return
            if status != REBALANCE_STATUS or time.monotonic() > deadline:
                raise DeployError(f"PUT config failed with {status}: {body}")
            LOGGER.info("Worker group is rebalancing (409); retrying")
            time.sleep(self.config.poll_seconds)

    def wait_until_running(self):
        """Wait until the connector and every task are RUNNING; fail fast on FAILED."""
        deadline = time.monotonic() + self.config.running_timeout_seconds
        while True:
            status, body = self.client.request("GET", self.path + "/status")
            if status == 200 and body:
                connector_state = body["connector"]["state"]
                tasks = body.get("tasks", [])
                failed = [t for t in tasks if t["state"] == "FAILED"]
                if connector_state == "FAILED" or failed:
                    trace = body["connector"].get("trace") or (failed[0].get("trace") if failed else "")
                    raise DeployError(f"connector or task FAILED:\n{trace}")
                if connector_state == "RUNNING" and tasks and all(t["state"] == "RUNNING" for t in tasks):
                    LOGGER.info("Connector RUNNING with %d task(s) on %s", len(tasks),
                             sorted({t["worker_id"] for t in tasks}))
                    return
                LOGGER.info("Connector %s, tasks %s; waiting", connector_state, [t["state"] for t in tasks])
            if time.monotonic() > deadline:
                raise DeployError("timed out waiting for the connector to reach RUNNING")
            time.sleep(self.config.poll_seconds)

    def deploy(self):
        """Run the full deployment."""
        connector_config = self.load_connector_config()
        self.wait_until_ready()
        self.put_config(connector_config)
        self.wait_until_running()


def main():
    """Main entry point."""
    try:
        config = DeployConfig.from_env()
        ConnectorDeployer(config).deploy()
    except KeyError as e:
        LOGGER.error("Missing required environment variable: %s", e)
        sys.exit(1)
    except (OSError, ValueError, DeployError) as e:
        LOGGER.error("Deployment failed: %s", e)
        sys.exit(1)
    LOGGER.info("Deployment complete")


if __name__ == "__main__":
    main()
