# Civica Connect on ECS

Self-managed Kafka Connect cluster on ECS Fargate for the Civica sink connector, connecting to MSK over
mutual TLS (MSK Connect only supports IAM or no client authentication).

## Layout

- `docker/Dockerfile`: Amazon Corretto 21 on AL2023 (same base as the Snowflake Connect image) and Apache Kafka 4.2.0 (matches `connect-api` in `pom.xml`), with
  the shaded connector JAR in `/app/plugins/cares-civica-connector`.
- `docker/connect-distributed.properties`: static worker settings baked into the image.
- `docker/start-kafka-connect.sh`: same pattern as the Snowflake worker script. Derives the IP, environment
  (container name suffix), group.id (task family), region and MSK bootstrap servers (looked up by the
  `cdi-db-infra--msk-cluster--<env>` name, TLS string) at startup, writes the PEM keystore, builds the
  runtime properties in `/tmp` and execs the worker.
- `cloudformation/civica-connect-ecs.yaml`: cluster, task definition, service, internal ALB, security groups,
  IAM, log group and CPU autoscaling.
- `deploy/deploy_connector.py`: creates or updates the connector with `PUT /connectors/{name}/config` and
  waits for RUNNING.
- `deploy/connector-<env>.properties`: connector config per environment.
- `buildspec.yml`: Maven build, image push, stack deploy, connector deploy.

## Copy into the connector repo

Put `docker/`, `cloudformation/`, `deploy/` and `buildspec.yml` at the root of the connector repo (next to
`pom.xml`). The Docker build context is the repo root, because the Dockerfile copies
`target/cares-civica-connector-*.jar`.

## Secrets

**MSK client certificate**: one secret with these JSON keys, from a certificate issued by the ACM Private CA
that the MSK cluster trusts (`aws acm export-certificate` returns all three plus an encrypted key):

```json
{
  "certificate": "-----BEGIN CERTIFICATE-----\n...",
  "certificate_chain": "-----BEGIN CERTIFICATE-----\n...",
  "private_key": "-----BEGIN ENCRYPTED PRIVATE KEY-----\n...",
  "private_key_password": "..."
}
```

The private key must be PKCS#8 (`BEGIN PRIVATE KEY` or `BEGIN ENCRYPTED PRIVATE KEY`), which is what ACM
exports. No truststore is needed: MSK broker certificates are issued by Amazon Trust Services, which the JVM
already trusts.

**Connector credentials**: one secret with JSON keys `sfdc_consumerkey`, `sfdc_consumersecret`,
`sfdc_user`, `sfdc_password`, `civica_user`, `civica_password`. ECS injects them as `CONNECTOR_SECRET_*` env
vars, and the connector config references them as `${env:CONNECTOR_SECRET_...}`. They never pass through
the REST API or get stored in the Connect configs topic.

## Kafka ACLs (if the cluster enforces them)

The principal is the client certificate's subject, e.g. `User:CN=civica-connect-dev`. It needs:

- Topics with prefix `civica-connect-<env>-` (the internal topics): Create, Describe, DescribeConfigs, Read, Write.
- Group `civica-connect-<env>` (the worker group): Read.
- Topic `aws.data-integration.cdc.cares.salesforce.mdm.0`: Describe, Read.
- Group `connect-<connector name>` (the sink consumer group): Read.

## Migrating from MSK Connect

A sink connector's consumer group is `connect-<connector name>`. Use the same connector name as the MSK
Connect connector, so the ECS connector resumes from its committed offsets.

1. Deploy the stack and confirm the workers are healthy (`GET /` on the ALB).
2. Delete the MSK Connect connector and wait until it is gone, so the two never consume at the same time.
3. Run `deploy_connector.py` with the same `CONNECTOR_NAME`.

## Scaling

Each partition is consumed by one task, and `tasks.max` is 2 for a 2-partition topic, so at most 2 workers do
work. The service runs a minimum of 2 tasks for availability. Autoscaling above 2 only adds idle workers until
the topic has more partitions (and the publisher keys messages by person). Every scale event rebalances the
worker group, so scale-in is deliberately slow (15-minute cooldown). Tasks from a stopped worker are reassigned
after 1 minute (`scheduled.rebalance.max.delay.ms`).

## Operations

- REST API: `http://<ConnectRestUrl>/connectors/<name>/status`.
- Log levels can be changed at runtime, e.g.
  `curl -X PUT -H 'Content-Type: application/json' -d '{"level":"DEBUG"}' http://<ConnectRestUrl>/admin/loggers/gov.ca.cares`.
  Each worker applies this only to itself, so repeat it per worker or use `?scope=cluster`.
- Shell into a worker: `aws ecs execute-command --cluster civica-connect-<env> --task <id> --container civica-connect-<env> --interactive --command /bin/bash`.
